# -*- coding: utf-8 -*-
import os
import zipfile

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
REPO_OWNER = "aco730"
REPO_NAME = "kodi-clone-backup"
API_BASE = "https://api.github.com/repos/{0}/{1}".format(REPO_OWNER, REPO_NAME)

ADDONS_DIR = xbmcvfs.translatePath("special://home/addons/")
USERDATA_DIR = xbmcvfs.translatePath("special://userdata/")
# Python's tempfile.gettempdir() fails on Android (no writable /tmp in the
# app sandbox) - use Kodi's own per-addon temp dir instead, which is always
# writable on every platform.
TEMP_DIR = xbmcvfs.translatePath("special://temp/")
if not os.path.exists(TEMP_DIR):
    os.makedirs(TEMP_DIR)

# Each own-hosted item: (label, kind, path-in-repo(s), addon ids to enable)
OWN_CATALOG = [
    ("DigiOnline.ro", "addon", "repository/addons/plugin.video.DigiOnline.ro/plugin.video.DigiOnline.ro-1.0.1.zip",
     ["plugin.video.DigiOnline.ro"]),
    ("Stiri RSS", "addon", "repository/addons/plugin.program.newsreader/plugin.program.newsreader-1.0.0.zip",
     ["plugin.program.newsreader"]),
    ("Weather (Gismeteo) + dependinte", "addon_multi", [
        "repository/addons/script.module.future/script.module.future-1.0.0+matrix.1.zip",
        "repository/addons/script.module.simpleplugin3/script.module.simpleplugin3-3.0.6+matrix.1.zip",
        "repository/addons/weather.gismeteo/weather.gismeteo-0.6.4+matrix.1.zip",
     ], ["script.module.future", "script.module.simpleplugin3", "weather.gismeteo"]),
    ("Skin Confluence (varianta mea, meniu/fundal custom)", "addon", "repository/addons/skin.confluence/skin.confluence-5.0.9.2.zip",
     ["skin.confluence"]),
]

# Third-party addons: installed from THEIR real, live repositories (not
# re-hosted here) so Kodi keeps checking those sources for real updates.
# (label, repo_addon_id, repo_zip_path_in_our_repo, target_addon_id)
THIRDPARTY_CATALOG = [
    ("TheCrew", "repository.thecrew",
     "repository/addons/repository.thecrew/repository.thecrew-0.3.8.zip", "plugin.video.thecrew"),
    ("Cumination", "repository.dobbelina",
     "repository/addons/repository.dobbelina/repository.dobbelina-1.0.4.zip", "plugin.video.cumination"),
    ("MadTitanSports", "repository.Magnetic",
     "repository/addons/repository.Magnetic/repository.Magnetic-1.1.0b.zip", "plugin.video.madtitansports"),
    ("POV", "repository.kodifitzwell",
     "repository/addons/repository.kodifitzwell/repository.kodifitzwell-0.0.1.zip", "plugin.video.pov"),
]

CATALOG = (
    [(label, kind, ref, ids) for (label, kind, ref, ids) in OWN_CATALOG]
    + [(label, "thirdparty", (repo_id, repo_zip, target_id), [repo_id, target_id])
       for (label, repo_id, repo_zip, target_id) in THIRDPARTY_CATALOG]
)
USERDATA_ITEM = ("Setarile mele personale (guisettings, credentiale, cookie-uri)", "userdata", "userdata-backup.zip", [])


def get_token():
    token = ADDON.getSetting("github_token")
    if token:
        return token
    dialog = xbmcgui.Dialog()
    token = dialog.input("GitHub token (repo privat, o singura data)", type=xbmcgui.INPUT_ALPHANUM)
    if not token:
        return None
    ADDON.setSetting("github_token", token)
    return token


def gh_headers(token):
    return {"Authorization": "token " + token, "Accept": "application/vnd.github.v3+json"}


def fetch_repo_file_bytes(token, path_in_repo):
    # Step 1: get the blob sha for this path (works for any file size).
    meta_url = "{0}/contents/{1}".format(API_BASE, path_in_repo)
    r = requests.get(meta_url, headers=gh_headers(token), timeout=30)
    if r.status_code != 200:
        raise Exception("{0}: {1}".format(r.status_code, r.text[:200]))
    sha = r.json()["sha"]

    # Step 2: fetch the raw blob content directly (handles files > 1MB too).
    blob_url = "{0}/git/blobs/{1}".format(API_BASE, sha)
    headers = gh_headers(token)
    headers["Accept"] = "application/vnd.github.raw"
    r2 = requests.get(blob_url, headers=headers, timeout=60)
    if r2.status_code != 200:
        raise Exception("blob {0}: {1}".format(r2.status_code, r2.text[:200]))
    return r2.content


def extract_zip_bytes(zip_bytes, dest_dir):
    tmp_zip = os.path.join(TEMP_DIR, "aco730_dl.zip")
    with open(tmp_zip, "wb") as f:
        f.write(zip_bytes)
    with zipfile.ZipFile(tmp_zip, "r") as zf:
        zf.extractall(dest_dir)
    os.remove(tmp_zip)


def enable_addon(addon_id):
    # Addons dropped directly on disk (not via Kodi's own installer) end up
    # registered but DISABLED - explicitly enable them via JSON-RPC.
    payload = (
        '{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
        '"params":{{"addonid":"{0}","enabled":true}},"id":1}}'
    ).format(addon_id)
    result = xbmc.executeJSONRPC(payload)
    xbmc.log("aco730restore: enable {0} -> {1}".format(addon_id, result), xbmc.LOGINFO)
    return '"error"' not in result


def addon_exists(addon_id):
    payload = (
        '{{"jsonrpc":"2.0","method":"Addons.GetAddonDetails",'
        '"params":{{"addonid":"{0}","properties":["enabled"]}},"id":1}}'
    ).format(addon_id)
    result = xbmc.executeJSONRPC(payload)
    return '"error"' not in result


def wait_for_addon_installed(addon_id, dialog, timeout_sec=90):
    waited = 0
    step = 3
    while waited < timeout_sec:
        if addon_exists(addon_id):
            enable_addon(addon_id)
            dialog.notification("aco730 Setup Wizard", addon_id + " - instalat", xbmcgui.NOTIFICATION_INFO, 3000)
            return True
        xbmc.sleep(step * 1000)
        waited += step
    dialog.notification("aco730 Setup Wizard", addon_id + " - NU s-a instalat (timeout)", xbmcgui.NOTIFICATION_ERROR, 5000)
    return False


def install_addon_zip(token, path_in_repo, progress, pct, label):
    progress.update(pct, "Descarc: " + label)
    data = fetch_repo_file_bytes(token, path_in_repo)
    extract_zip_bytes(data, ADDONS_DIR)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmcgui.Dialog().notification("aco730 Setup Wizard", label + " - descarcat", xbmcgui.NOTIFICATION_INFO, 2500)


def restore_userdata(token, progress, pct):
    progress.update(pct, "Descarc setarile personale...")
    data = fetch_repo_file_bytes(token, "userdata-backup.zip")
    extract_zip_bytes(data, USERDATA_DIR)
    xbmcgui.Dialog().notification("aco730 Setup Wizard", "Setari personale - restaurate", xbmcgui.NOTIFICATION_INFO, 2500)


def install_thirdparty(token, ref, progress, pct, label):
    repo_id, repo_zip_path, target_id = ref
    dialog = xbmcgui.Dialog()

    # Already installed and working? Skip straight to confirming/enabling.
    if addon_exists(target_id):
        enable_addon(target_id)
        dialog.notification("aco730 Setup Wizard", label + " - deja instalat", xbmcgui.NOTIFICATION_INFO, 2500)
        return True

    progress.update(pct, "Descarc repo: " + repo_id)
    data = fetch_repo_file_bytes(token, repo_zip_path)
    extract_zip_bytes(data, ADDONS_DIR)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.sleep(1500)
    # The repository addon must be ENABLED before Kodi will fetch anything
    # from it - InstallAddon() silently no-ops against a disabled repository.
    enable_addon(repo_id)
    dialog.notification("aco730 Setup Wizard", repo_id + " - activat", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.sleep(1500)

    progress.update(pct, "Instalez: " + label)
    xbmc.executebuiltin("InstallAddon({0})".format(target_id))
    return wait_for_addon_installed(target_id, dialog)


def run_one(token, label, kind, ref, progress, pct):
    if kind == "addon":
        install_addon_zip(token, ref, progress, pct, label)
    elif kind == "addon_multi":
        for p in ref:
            install_addon_zip(token, p, progress, pct, label)
    elif kind == "thirdparty":
        install_thirdparty(token, ref, progress, pct, label)


def main():
    dialog = xbmcgui.Dialog()
    all_items = CATALOG + [USERDATA_ITEM]
    labels = [c[0] for c in all_items]
    selected = dialog.multiselect("aco730 - Setup Wizard (bifeaza ce vrei instalat)", labels, preselect=list(range(len(labels))))
    if not selected:
        return

    token = get_token()
    if not token:
        dialog.notification("Setup Wizard", "Anulat (fara token)", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    progress = xbmcgui.DialogProgress()
    progress.create("aco730 - Setup Wizard", "Pornesc...")

    # Addons first, each installed and confirmed on its own (not as one bulk
    # step) - settings/credentials are applied last, only after that.
    addon_selection = [i for i in selected if all_items[i] is not USERDATA_ITEM]
    want_userdata = any(all_items[i] is USERDATA_ITEM for i in selected)

    errors = []
    total = len(addon_selection) + (1 if want_userdata else 0)
    done = 0
    for idx in addon_selection:
        if progress.iscanceled():
            break
        label, kind, ref, addon_ids = all_items[idx]
        pct = int((done / float(total)) * 100) if total else 0
        progress.update(pct, label)
        try:
            run_one(token, label, kind, ref, progress, pct)
        except Exception as e:
            errors.append("{0}: {1}".format(label, e))
        done += 1

    if want_userdata and not progress.iscanceled():
        pct = int((done / float(total)) * 100) if total else 0
        try:
            restore_userdata(token, progress, pct)
        except Exception as e:
            errors.append("Setari personale: {0}".format(e))

    progress.update(100, "Gata")
    progress.close()

    xbmc.executebuiltin("UpdateLocalAddons")

    if errors:
        dialog.ok("Setup Wizard - erori", "\n".join(errors))
    else:
        dialog.ok(
            "aco730 - Setup Wizard",
            "Gata! Restarteaza Kodi acum ca totul sa se aplice complet "
            "(skin, addon-uri, setari).",
        )
    xbmc.log("aco730restore: wizard run finished, errors=" + str(errors), xbmc.LOGINFO)


if __name__ == "__main__":
    main()
