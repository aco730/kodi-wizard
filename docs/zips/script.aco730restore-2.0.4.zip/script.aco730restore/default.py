# -*- coding: utf-8 -*-
import os
import zipfile

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
REPO_OWNER = "aco730"
REPO_NAME = "kodi-clone-backup"
API_BASE = "https://api.github.com/repos/{0}/{1}".format(REPO_OWNER, REPO_NAME)

ADDONS_DIR = xbmcvfs.translatePath("special://home/addons/")
USERDATA_DIR = xbmcvfs.translatePath("special://userdata/")
# Python's tempfile.gettempdir() fails on Android (no writable /tmp in the
# app sandbox) - use Kodi's own per-addon temp dir instead, which is always
# writable on every platform.
TEMP_DIR = xbmcvfs.translatePath("special://temp/")
if not os.path.exists(TEMP_DIR):
    os.makedirs(TEMP_DIR)

# (checkbox label, kind, path-in-repo or addon id list, addon ids to enable afterwards)
CATALOG = [
    ("Setarile mele personale (guisettings, credentiale, cookie-uri)", "userdata", "userdata-backup.zip", []),
    ("DigiOnline.ro", "addon", "repository/addons/plugin.video.DigiOnline.ro/plugin.video.DigiOnline.ro-1.0.1.zip",
     ["plugin.video.DigiOnline.ro"]),
    ("Stiri RSS", "addon", "repository/addons/plugin.program.newsreader/plugin.program.newsreader-1.0.0.zip",
     ["plugin.program.newsreader"]),
    ("Weather (Gismeteo) + dependinte", "addon_multi", [
        "repository/addons/script.module.future/script.module.future-1.0.0+matrix.1.zip",
        "repository/addons/script.module.simpleplugin3/script.module.simpleplugin3-3.0.6+matrix.1.zip",
        "repository/addons/weather.gismeteo/weather.gismeteo-0.6.4+matrix.1.zip",
     ], ["script.module.future", "script.module.simpleplugin3", "weather.gismeteo"]),
    ("Skin Confluence (varianta mea, meniu/fundal custom)", "addon", "repository/addons/skin.confluence/skin.confluence-5.0.9.1.zip",
     ["skin.confluence"]),
    ("TheCrew + Cumination + MadTitanSports + POV (live, auto-update real)", "thecrew", None,
     ["repository.thecrew", "plugin.video.thecrew", "plugin.video.cumination",
      "plugin.video.madtitansports", "plugin.video.pov"]),
]


def get_token():
    token = ADDON.getSetting("github_token")
    if token:
        return token
    dialog = xbmcgui.Dialog()
    token = dialog.input("GitHub token (repo privat, o singura data)", type=xbmcgui.INPUT_ALPHANUM)
    if not token:
        return None
    ADDON.setSetting("github_token", token)
    return token


def gh_headers(token):
    return {"Authorization": "token " + token, "Accept": "application/vnd.github.v3+json"}


def fetch_repo_file_bytes(token, path_in_repo):
    # Step 1: get the blob sha for this path (works for any file size).
    meta_url = "{0}/contents/{1}".format(API_BASE, path_in_repo)
    r = requests.get(meta_url, headers=gh_headers(token), timeout=30)
    if r.status_code != 200:
        raise Exception("{0}: {1}".format(r.status_code, r.text[:200]))
    sha = r.json()["sha"]

    # Step 2: fetch the raw blob content directly (handles files > 1MB too).
    blob_url = "{0}/git/blobs/{1}".format(API_BASE, sha)
    headers = gh_headers(token)
    headers["Accept"] = "application/vnd.github.raw"
    r2 = requests.get(blob_url, headers=headers, timeout=60)
    if r2.status_code != 200:
        raise Exception("blob {0}: {1}".format(r2.status_code, r2.text[:200]))
    return r2.content


def enable_addon(addon_id):
    # Addons dropped directly on disk (not via Kodi's own installer) end up
    # registered but DISABLED - explicitly enable them via JSON-RPC.
    payload = (
        '{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
        '"params":{{"addonid":"{0}","enabled":true}},"id":1}}'
    ).format(addon_id)
    result = xbmc.executeJSONRPC(payload)
    xbmc.log("aco730restore: enable {0} -> {1}".format(addon_id, result), xbmc.LOGINFO)


def extract_zip_bytes(zip_bytes, dest_dir):
    tmp_zip = os.path.join(TEMP_DIR, "aco730_dl.zip")
    with open(tmp_zip, "wb") as f:
        f.write(zip_bytes)
    with zipfile.ZipFile(tmp_zip, "r") as zf:
        zf.extractall(dest_dir)
    os.remove(tmp_zip)


def install_addon_zip(token, path_in_repo, progress, pct, label):
    progress.update(pct, "Descarc: " + label)
    data = fetch_repo_file_bytes(token, path_in_repo)
    extract_zip_bytes(data, ADDONS_DIR)


def restore_userdata(token, progress, pct):
    progress.update(pct, "Descarc setarile personale...")
    data = fetch_repo_file_bytes(token, "userdata-backup.zip")
    extract_zip_bytes(data, USERDATA_DIR)


def install_thecrew_bundle(token, progress, pct):
    progress.update(pct, "Descarc repository.thecrew...")
    data = fetch_repo_file_bytes(token, "repository/addons/repository.thecrew/repository.thecrew-0.3.8.zip")
    extract_zip_bytes(data, ADDONS_DIR)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.sleep(1500)
    # repository.thecrew must be ENABLED before Kodi will fetch anything from
    # it - InstallAddon() silently no-ops against a disabled repository.
    enable_addon("repository.thecrew")
    xbmc.sleep(1000)
    for addon_id in ("plugin.video.thecrew", "plugin.video.cumination",
                      "plugin.video.madtitansports", "plugin.video.pov"):
        progress.update(pct, "Instalez: " + addon_id)
        xbmc.executebuiltin("InstallAddon({0})".format(addon_id))
        xbmc.sleep(4000)
        enable_addon(addon_id)


def main():
    dialog = xbmcgui.Dialog()
    labels = [c[0] for c in CATALOG]
    selected = dialog.multiselect("aco730 - Setup Wizard (bifeaza ce vrei instalat)", labels, preselect=list(range(len(labels))))
    if not selected:
        return

    token = get_token()
    if not token:
        dialog.notification("Setup Wizard", "Anulat (fara token)", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    progress = xbmcgui.DialogProgress()
    progress.create("aco730 - Setup Wizard", "Pornesc...")

    errors = []
    to_enable = []
    total = len(selected)
    for i, idx in enumerate(selected):
        if progress.iscanceled():
            break
        label, kind, ref, addon_ids = CATALOG[idx]
        pct = int((i / float(total)) * 100)
        progress.update(pct, label)
        try:
            if kind == "userdata":
                restore_userdata(token, progress, pct)
            elif kind == "addon":
                install_addon_zip(token, ref, progress, pct, label)
            elif kind == "addon_multi":
                for p in ref:
                    install_addon_zip(token, p, progress, pct, label)
            elif kind == "thecrew":
                install_thecrew_bundle(token, progress, pct)
            to_enable.extend(addon_ids)
        except Exception as e:
            errors.append("{0}: {1}".format(label, e))

    if to_enable:
        progress.update(95, "Activez addon-urile instalate...")
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.sleep(2000)
        for addon_id in to_enable:
            enable_addon(addon_id)
        xbmc.sleep(500)

    progress.update(100, "Gata")
    progress.close()

    xbmc.executebuiltin("UpdateLocalAddons")

    if errors:
        dialog.ok("Setup Wizard - erori", "\n".join(errors))
    else:
        dialog.ok(
            "aco730 - Setup Wizard",
            "Gata! Restarteaza Kodi acum ca totul sa se aplice complet "
            "(skin, addon-uri, setari).",
        )
    xbmc.log("aco730restore: wizard run finished, errors=" + str(errors), xbmc.LOGINFO)


if __name__ == "__main__":
    main()
