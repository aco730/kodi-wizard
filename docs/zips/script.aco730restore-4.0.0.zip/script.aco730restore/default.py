# -*- coding: utf-8 -*-
import os
import re
import zipfile

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
REPO_OWNER = "aco730"
REPO_NAME = "kodi-clone-backup"
API_BASE = "https://api.github.com/repos/{0}/{1}".format(REPO_OWNER, REPO_NAME)

ADDONS_DIR = xbmcvfs.translatePath("special://home/addons/")
USERDATA_DIR = xbmcvfs.translatePath("special://userdata/")
# Python's tempfile.gettempdir() fails on Android (no writable /tmp in the
# app sandbox) - use Kodi's own per-addon temp dir instead, which is always
# writable on every platform.
TEMP_DIR = xbmcvfs.translatePath("special://temp/")
if not os.path.exists(TEMP_DIR):
    os.makedirs(TEMP_DIR)

# Each own-hosted item: (label, kind, path-in-repo(s), addon ids to enable)
OWN_CATALOG = [
    ("DigiOnline.ro", "addon", "repository/addons/plugin.video.DigiOnline.ro/plugin.video.DigiOnline.ro-1.0.1.zip",
     ["plugin.video.DigiOnline.ro"]),
    ("Stiri RSS", "addon", "repository/addons/plugin.program.newsreader/plugin.program.newsreader-1.0.0.zip",
     ["plugin.program.newsreader"]),
    ("Weather (Gismeteo) + dependinte", "addon_multi", [
        "repository/addons/script.module.future/script.module.future-1.0.0+matrix.1.zip",
        "repository/addons/script.module.simpleplugin3/script.module.simpleplugin3-3.0.6+matrix.1.zip",
        "repository/addons/weather.gismeteo/weather.gismeteo-0.6.4+matrix.1.zip",
     ], ["script.module.future", "script.module.simpleplugin3", "weather.gismeteo"]),
    ("Skin Confluence (varianta mea, meniu/fundal custom)", "addon", "repository/addons/skin.confluence/skin.confluence-5.0.9.2.zip",
     ["skin.confluence"]),
]

# Third-party addons: fetched DIRECTLY from their real, live manifests (not
# re-hosted here, and NOT via Kodi's InstallAddon() builtin - that always
# pops a confirmation dialog). We read their current version from the
# manifest ourselves and download the zip straight from the same public host
# they use, so it's both silent AND always the latest version.
# (label, repo_addon_id_or_None, repo_zip_path_in_our_repo_or_None,
#  manifest_url, datadir_base_url, target_addon_id)
THIRDPARTY_CATALOG = [
    ("TheCrew", "repository.thecrew",
     "repository/addons/repository.thecrew/repository.thecrew-0.3.8.zip",
     "https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip/addons.xml",
     "https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip/",
     "plugin.video.thecrew"),
    ("Cumination", "repository.dobbelina",
     "repository/addons/repository.dobbelina/repository.dobbelina-1.0.4.zip",
     "https://raw.githubusercontent.com/dobbelina/repository.dobbelina/master/addons.xml",
     "https://raw.githubusercontent.com/dobbelina/repository.dobbelina/master/",
     "plugin.video.cumination"),
    ("MadTitanSports", "repository.Magnetic",
     "repository/addons/repository.Magnetic/repository.Magnetic-1.1.0b.zip",
     "https://magnetic.website/__zips/addons.xml",
     "https://magnetic.website/__zips/",
     "plugin.video.madtitansports"),
    ("POV", "repository.kodifitzwell",
     "repository/addons/repository.kodifitzwell/repository.kodifitzwell-0.0.1.zip",
     "https://kodiyashimaru.github.io/repo/packages/addons.xml",
     "https://kodiyashimaru.github.io/repo/",
     "plugin.video.pov"),
    ("OpenSubtitles.com", "repository.xbmc.org", None,
     "https://mirrors.kodi.tv/addons/omega/addons.xml",
     "https://mirrors.kodi.tv/addons/omega/",
     "service.subtitles.opensubtitles-com"),
    ("YouTube", "repository.xbmc.org", None,
     "https://mirrors.kodi.tv/addons/omega/addons.xml",
     "https://mirrors.kodi.tv/addons/omega/",
     "plugin.video.youtube"),
]

CATALOG = (
    [(label, kind, ref, ids) for (label, kind, ref, ids) in OWN_CATALOG]
    + [(label, "thirdparty", (repo_id, repo_zip, manifest_url, datadir, target_id), [target_id])
       for (label, repo_id, repo_zip, manifest_url, datadir, target_id) in THIRDPARTY_CATALOG]
)
USERDATA_ITEM = ("Setarile mele personale (guisettings, credentiale, cookie-uri)", "userdata", "userdata-backup.zip", [])


def get_token():
    token = ADDON.getSetting("github_token")
    if token:
        return token
    dialog = xbmcgui.Dialog()
    token = dialog.input("GitHub token (repo privat, o singura data)", type=xbmcgui.INPUT_ALPHANUM)
    if not token:
        return None
    ADDON.setSetting("github_token", token)
    return token


def gh_headers(token):
    return {"Authorization": "token " + token, "Accept": "application/vnd.github.v3+json"}


def fetch_repo_file_bytes(token, path_in_repo):
    # Step 1: get the blob sha for this path (works for any file size).
    meta_url = "{0}/contents/{1}".format(API_BASE, path_in_repo)
    r = requests.get(meta_url, headers=gh_headers(token), timeout=30)
    if r.status_code != 200:
        raise Exception("{0}: {1}".format(r.status_code, r.text[:200]))
    sha = r.json()["sha"]

    # Step 2: fetch the raw blob content directly (handles files > 1MB too).
    blob_url = "{0}/git/blobs/{1}".format(API_BASE, sha)
    headers = gh_headers(token)
    headers["Accept"] = "application/vnd.github.raw"
    r2 = requests.get(blob_url, headers=headers, timeout=60)
    if r2.status_code != 200:
        raise Exception("blob {0}: {1}".format(r2.status_code, r2.text[:200]))
    return r2.content


def extract_zip_bytes(zip_bytes, dest_dir):
    tmp_zip = os.path.join(TEMP_DIR, "aco730_dl.zip")
    with open(tmp_zip, "wb") as f:
        f.write(zip_bytes)
    with zipfile.ZipFile(tmp_zip, "r") as zf:
        zf.extractall(dest_dir)
    os.remove(tmp_zip)


def enable_addon(addon_id):
    # Addons dropped directly on disk (not via Kodi's own installer) end up
    # registered but DISABLED - explicitly enable them via JSON-RPC.
    payload = (
        '{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
        '"params":{{"addonid":"{0}","enabled":true}},"id":1}}'
    ).format(addon_id)
    result = xbmc.executeJSONRPC(payload)
    xbmc.log("aco730restore: enable {0} -> {1}".format(addon_id, result), xbmc.LOGINFO)
    return '"error"' not in result


def addon_exists(addon_id):
    payload = (
        '{{"jsonrpc":"2.0","method":"Addons.GetAddonDetails",'
        '"params":{{"addonid":"{0}","properties":["enabled"]}},"id":1}}'
    ).format(addon_id)
    result = xbmc.executeJSONRPC(payload)
    return '"error"' not in result


def install_addon_zip(token, path_in_repo, progress, pct, label):
    progress.update(pct, "Descarc: " + label)
    data = fetch_repo_file_bytes(token, path_in_repo)
    extract_zip_bytes(data, ADDONS_DIR)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmcgui.Dialog().notification("aco730 Setup Wizard", label + " - descarcat", xbmcgui.NOTIFICATION_INFO, 2500)


def restore_userdata(token, progress, pct):
    progress.update(pct, "Descarc setarile personale...")
    data = fetch_repo_file_bytes(token, "userdata-backup.zip")
    extract_zip_bytes(data, USERDATA_DIR)
    xbmcgui.Dialog().notification("aco730 Setup Wizard", "Setari personale - restaurate", xbmcgui.NOTIFICATION_INFO, 2500)


def fetch_public_bytes(url, timeout=60):
    r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
    if r.status_code != 200:
        raise Exception("{0}: HTTP {1}".format(url, r.status_code))
    return r.content


def latest_version_from_manifest(manifest_bytes, addon_id):
    text = manifest_bytes.decode("utf-8", errors="replace")
    m = re.search(r'<addon\s+id="{0}"[^>]*\bversion="([^"]+)"'.format(re.escape(addon_id)), text)
    if not m:
        # attribute order can vary (name before version, etc.)
        m = re.search(r'<addon\s+[^>]*\bid="{0}"[^>]*\bversion="([^"]+)"'.format(re.escape(addon_id)), text)
    if not m:
        raise Exception("addon id not found in manifest: " + addon_id)
    return m.group(1)


def install_thirdparty(token, ref, progress, pct, label):
    repo_id, repo_zip_path, manifest_url, datadir_base, target_id = ref
    dialog = xbmcgui.Dialog()

    # Already installed and working? Skip straight to confirming/enabling.
    if addon_exists(target_id):
        enable_addon(target_id)
        dialog.notification("aco730 Setup Wizard", label + " - deja instalat", xbmcgui.NOTIFICATION_INFO, 2500)
        return True

    # 1) Keep the small repository pointer installed too (silently), so Kodi
    #    keeps auto-checking that source for future updates on its own.
    if repo_zip_path:
        data = fetch_repo_file_bytes(token, repo_zip_path)
        extract_zip_bytes(data, ADDONS_DIR)
        enable_addon(repo_id)
    elif repo_id and not addon_exists(repo_id):
        dialog.notification("aco730 Setup Wizard", repo_id + " lipseste pe acest Kodi (" + label + " tot merge, doar update-urile automate nu)", xbmcgui.NOTIFICATION_WARNING, 4000)

    # 2) Fetch the addon itself DIRECTLY - no InstallAddon() builtin, so no
    #    confirmation popup. We read the current version from their live
    #    manifest first, so this is always the latest build, same as a real
    #    Kodi repo install would give you.
    progress.update(pct, "Verific versiune: " + label)
    manifest = fetch_public_bytes(manifest_url)
    version = latest_version_from_manifest(manifest, target_id)

    progress.update(pct, "Descarc: {0} v{1}".format(label, version))
    zip_url = "{0}{1}/{1}-{2}.zip".format(datadir_base, target_id, version)
    data = fetch_public_bytes(zip_url)
    extract_zip_bytes(data, ADDONS_DIR)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.sleep(1000)
    ok = enable_addon(target_id)
    if ok:
        dialog.notification("aco730 Setup Wizard", "{0} v{1} - instalat".format(label, version), xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        dialog.notification("aco730 Setup Wizard", label + " - eroare la activare", xbmcgui.NOTIFICATION_ERROR, 4000)
    return ok


def run_one(token, label, kind, ref, progress, pct):
    if kind == "addon":
        install_addon_zip(token, ref, progress, pct, label)
    elif kind == "addon_multi":
        for p in ref:
            install_addon_zip(token, p, progress, pct, label)
    elif kind == "thirdparty":
        install_thirdparty(token, ref, progress, pct, label)


def main():
    dialog = xbmcgui.Dialog()
    all_items = CATALOG + [USERDATA_ITEM]
    labels = [c[0] for c in all_items]
    selected = dialog.multiselect("aco730 - Setup Wizard (bifeaza ce vrei instalat)", labels, preselect=list(range(len(labels))))
    if not selected:
        return

    token = get_token()
    if not token:
        dialog.notification("Setup Wizard", "Anulat (fara token)", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    progress = xbmcgui.DialogProgress()
    progress.create("aco730 - Setup Wizard", "Pornesc...")

    # Addons first, each installed and confirmed on its own (not as one bulk
    # step) - settings/credentials are applied last, only after that.
    addon_selection = [i for i in selected if all_items[i] is not USERDATA_ITEM]
    want_userdata = any(all_items[i] is USERDATA_ITEM for i in selected)

    errors = []
    total = len(addon_selection) + (1 if want_userdata else 0)
    done = 0
    for idx in addon_selection:
        if progress.iscanceled():
            break
        label, kind, ref, addon_ids = all_items[idx]
        pct = int((done / float(total)) * 100) if total else 0
        progress.update(pct, label)
        try:
            run_one(token, label, kind, ref, progress, pct)
        except Exception as e:
            errors.append("{0}: {1}".format(label, e))
        done += 1

    if want_userdata and not progress.iscanceled():
        pct = int((done / float(total)) * 100) if total else 0
        try:
            restore_userdata(token, progress, pct)
        except Exception as e:
            errors.append("Setari personale: {0}".format(e))

    progress.update(100, "Gata")
    progress.close()

    xbmc.executebuiltin("UpdateLocalAddons")

    if errors:
        dialog.ok("Setup Wizard - erori", "\n".join(errors))
    else:
        dialog.ok(
            "aco730 - Setup Wizard",
            "Gata! Restarteaza Kodi acum ca totul sa se aplice complet "
            "(skin, addon-uri, setari).",
        )
    xbmc.log("aco730restore: wizard run finished, errors=" + str(errors), xbmc.LOGINFO)


if __name__ == "__main__":
    main()
